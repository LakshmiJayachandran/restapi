
<title>REST API for Devices</title>

<div class="container">
	<h2>REST API for Devices</h2>	
	<br>
	<br>
	<?PHP if(!empty($_GET['msg'])=='success'){ ?>
	<tr>
	   <div style="color: white; border: solid 2px ; text-align:center; background-color: Green"><b>&nbsp;Devices has been added successfully</b></div>
	</tr><p>&nbsp;</p>
	<?PHP } ?>
	<form class="form-inline" action="RestController.php" method="POST">
		<div class="form-group">
			<label for="name">Device ID</label>
			<input type="text" name="device_id" class="form-control"  placeholder="Enter Device Id" required/></br></br>
			<label for="name">Device Name</label>
			<input type="text" name="device_label" class="form-control"  placeholder="Enter Device Name" required/></br></br>
			<label for="name">Last Reported Date</label>
			<input type="datetime-local" name="last_reported_date" class="form-control"  placeholder="Enter Date time" required/></br></br>
		</div>
		<button type="submit" name="submit" class="btn btn-default">Add</button>
	</form>
	<p>&nbsp;</p>

	<div style="margin:50px 0px 0px 0px;">
		<a class="btn btn-default read-more" style="background:#3399ff;color:white" href="./RestController.php?page_key=list" target="_blank">List of All Devices</a>		
	</div>
</div>

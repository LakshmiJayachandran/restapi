<?php
require_once("dbcontroller.php");
/* 
A domain Class to demonstrate RESTful web services
*/
Class Device {
	private $Devices = array();
	public function getAllDevice(){
		if(isset($_GET['name'])){
			$name = $_GET['name'];
			$query = 'SELECT * FROM Devices WHERE device_label LIKE "%' .$name. '%"';
		} else {
			$query = 'SELECT * FROM Devices';
		}
		$dbcontroller = new DBController();
		$this->Devices = $dbcontroller->executeSelectQuery($query);
		return $this->Devices;
	}

	public function addDevice(){
		if(isset($_POST['device_id'])){
			$device_id = $_POST['device_id'];
				$device_label = '';
				$last_reported_date = '';
			if(isset($_POST['device_label'])){
				$device_label = $_POST['device_label'];
			}
			if(isset($_POST['last_reported_date'])){
				$last_reported_date = $_POST['last_reported_date'];
			}			
			$query = "insert into Devices (device_id,device_label,last_reported_date) values ('" . $device_id ."','". $device_label ."','" . $last_reported_date ."')";
			$dbcontroller = new DBController();
			$result = $dbcontroller->executeQuery($query);
			if($result != 0){
				$result = array('success'=>1);
				return $result;
			}
		}
	}
	
	public function deleteDevice(){
		if(isset($_GET['id'])){
			$id = $_GET['id'];
			$query = 'DELETE FROM Devices WHERE id = '.$id;
			$dbcontroller = new DBController();
			$result = $dbcontroller->executeQuery($query);
			if($result != 0){
				$result = array('success'=>1);
				return $result;
			}
		}
	}
	
	public function editDevice(){
		if(isset($_POST['name']) && isset($_GET['id'])){
			$device_id = $_POST['device_id'];
			$device_label = $_POST['device_label'];
			$last_reported_date = $_POST['last_reported_date'];
			$query = "UPDATE Devices SET device_id = '".$device_id."',device_label ='". $device_label ."',last_reported_date = '". $last_reported_date ."' WHERE id = ".$_GET['id'];
		}
		$dbcontroller = new DBController();
		$result= $dbcontroller->executeQuery($query);
		if($result != 0){
			$result = array('success'=>1);
			return $result;
		}
	}
	
}
?>
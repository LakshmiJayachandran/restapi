-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 01, 2018 at 08:18 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `telematics`
--

-- --------------------------------------------------------

--
-- Table structure for table `devices`
--

CREATE TABLE `devices` (
  `id` int(11) NOT NULL,
  `device_id` varchar(50) DEFAULT NULL,
  `device_label` varchar(200) DEFAULT NULL,
  `last_reported_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `devices`
--

INSERT INTO `devices` (`id`, `device_id`, `device_label`, `last_reported_date`) VALUES
(1, '001', 'Lexus Gen V navigation system', '2017-12-29 21:44:07'),
(3, '002', 'Pictor Telematics', '2017-12-30 21:44:07'),
(4, '003', 'GPS TRACKER GPS104', '2017-11-22 21:44:07'),
(5, '004', 'WIRELESS TRACKER', '2017-12-30 20:20:00'),
(6, '005', 'Lex Gen VI Nav', '2017-12-30 21:44:07'),
(12, '009', 'GPS TRACKER GPS106', '2018-01-01 21:44:07'),
(13, '010', 'GPS TRACKER GPS107', '2017-12-29 21:44:07'),
(14, '011', 'GPS TRACKER GPS107', '2018-01-01 21:44:07'),
(16, '011', 'GPS TRACKER GPS107', '2017-12-31 21:44:07');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `devices`
--
ALTER TABLE `devices`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `devices`
--
ALTER TABLE `devices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

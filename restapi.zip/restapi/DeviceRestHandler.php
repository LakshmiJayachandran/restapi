<?php
require_once("SimpleRest.php");
require_once("Device.php");
		
class DeviceRestHandler extends SimpleRest {

	function getAllDevices() {	

		$Device = new Device();
		$rawData = $Device->getAllDevice();

		if(empty($rawData)) {
			$statusCode = 404;
			$rawData = array('success' => 0);		
		} else {
			$statusCode = 200;
		}

		$requestContentType = $_SERVER['HTTP_ACCEPT'];
		$this ->setHttpHeaders($requestContentType, $statusCode);
		
		$result["output"] = $rawData;
				
	/*	if(strpos($requestContentType,'application/json') !== false){
			$response = $this->encodeJson($result);
			echo $response;
		}*/
		if(strpos($requestContentType,'application/json') !== false){
			$response = $this->encodeJson($rawData);
			echo $response;
		} else if(strpos($requestContentType,'text/html') !== false){
			$response = $this->encodelistHtml($rawData);
			echo $response;
		} else if(strpos($requestContentType,'application/xml') !== false){
			$response = $this->encodeXml($rawData);
			echo $response;
		}
	}
	
	function add() {	
		$Device = new Device();
		$rawData = $Device->addDevice();
		if(empty($rawData)) {
			$statusCode = 404;
			$rawData = array('success' => 0);		
		} else {
			$statusCode = 200;
		}
		
		$requestContentType = $_SERVER['HTTP_ACCEPT'];
		$this ->setHttpHeaders($requestContentType, $statusCode);
		$result = $rawData;
		//print_r	($requestContentType);
		if(strpos($requestContentType,'application/json') !== false){
			$response = $this->encodeJson($rawData);
			echo $response;
		} else if(strpos($requestContentType,'text/html') !== false){
			$response = $this->encodeHtml($rawData);
			echo $response;
		} else if(strpos($requestContentType,'application/xml') !== false){
			$response = $this->encodeXml($rawData);
			echo $response;
		}
	}

	function deleteDeviceById() {	
		$Device = new Device();
		$rawData = $Device->deleteDevice();
		
		if(empty($rawData)) {
			$statusCode = 404;
			$rawData = array('success' => 0);		
		} else {
			$statusCode = 200;
		}
		
		$requestContentType = $_SERVER['HTTP_ACCEPT'];
		$this ->setHttpHeaders($requestContentType, $statusCode);
		$result = $rawData;
				
		if(strpos($requestContentType,'application/json') !== false){
			$response = $this->encodeJson($result);
			echo $response;
		}
	}
	
	function editDeviceById() {	
		$Device = new Device();
		$rawData = $Device->editDevice();
		if(empty($rawData)) {
			$statusCode = 404;
			$rawData = array('success' => 0);		
		} else {
			$statusCode = 200;
		}
		
		$requestContentType = $_SERVER['HTTP_ACCEPT'];
		$this ->setHttpHeaders($requestContentType, $statusCode);
		$result = $rawData;
				
		if(strpos($requestContentType,'application/json') !== false){
			$response = $this->encodeJson($result);
			echo $response;
		}
	}
	
	public function encodelistHtml($responseData) {
		
				// getting current date 
		$cDate = strtotime(date('Y-m-d H:i:s'));

		
		$htmlResponse = "<table border='1'>";
		$htmlResponse .= "<tr><td><b>". 'Device Id'. "</td><td><b>". 'Device Name'. "</td><td><b>". 'Last Reported Date'. "</td><td><b>". 'Status'. "</b></td></tr>";
		foreach($responseData as $key=>$value) {
			// Getting the value of old date + 24 hours
		$oldDate = strtotime($value['last_reported_date']) + 86400; // 86400 seconds in 24 hrs

		if($oldDate > $cDate)
		{
		  $status='<div style="color: white; border: solid 2px ; text-align:center; background-color: Green">'.'OK'.'</div>';
		}
		else
		{
		  $status= '<div style="color: white; border: solid 2px ; text-align:center; background-color: Red">'.'OFFLINE'.'</div>'; //outputs no
		}
		$htmlResponse .= "<tr><td>". $value['device_id']. "</td><td>". $value['device_label']. "</td><td>". $value['last_reported_date']. "</td><td>". $status. "</td></tr>";		
		}
		
		$htmlResponse .= "</table>";
		$htmlResponse .= "<div style='margin:50px 0px 0px 0px;'>
		<a class='btn btn-default read-more' style='background:#3399ff;color:white' href='./index.php' target='_blank'>Add Devices</a>		
	</div>";
		return $htmlResponse;		
	}
	
	public function encodeHtml($responseData) {
		
		//echo $responseData;
		header("location:index.php?msg=success");
		
		$htmlResponse = "<table border='1'>";
		$htmlResponse .= "<tr><td>". 'device_id'. "</td><td>". 'device_label'. "</td><td>". 'last_reported_date'. "</td></tr>";
		foreach($responseData as $key=>$value) {
		$htmlResponse .= "<tr><td>". $value['device_id']. "</td><td>". $value['device_label']. "</td><td>". $value['last_reported_date']. "</td></tr>";		
		}
		
		$htmlResponse .= "</table>";
		return $htmlResponse;		
	}
	
	public function encodeJson($responseData) {
		$jsonResponse = json_encode($responseData);
		return $jsonResponse;		
	}
}
?>
you can view the site

http://localhost/restapi/index.php - for add

http://localhost/restapi/RestController.php?page_key=list - view all devices

otherwise you can use the .htaccess file to add in virtual host

http://localhost/restapi/device/list


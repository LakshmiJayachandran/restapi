<?php
require_once("DeviceRestHandler.php"); //echo 'correct';
$method = $_SERVER['REQUEST_METHOD']; //print_r($_POST);
$view = "";
if(isset($_GET["page_key"]))
	$page_key = $_GET["page_key"]; 
else
	$page_key = 'create'; 

if(isset($_POST))
	//$page_key = 'create'; 
/*
controls the RESTful services
URL mapping
*/
	switch($page_key){

		case "list":
			// to handle REST Url /device/list/
			//echo 'correct';
			$DeviceRestHandler = new DeviceRestHandler();
			$result = $DeviceRestHandler->getAllDevices();
			break;
	
		case "create":
			// to handle REST Url /device/create/
			$DeviceRestHandler = new DeviceRestHandler();
			$DeviceRestHandler->add();
		break;
		
		case "delete":
			// to handle REST Url /device/delete/<row_id>
			$DeviceRestHandler = new DeviceRestHandler();
			$result = $DeviceRestHandler->deleteDeviceById();
		break;
		
		case "update":
			// to handle REST Url /device/update/<row_id>
			$DeviceRestHandler = new DeviceRestHandler();
			$DeviceRestHandler->editDeviceById();
		break;
}
?>
